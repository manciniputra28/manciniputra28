"use client"

import React, { useState, useEffect } from 'react';
import { 
  Twitter, 
  Instagram, 
  MessageCircle, 
  Github, 
  Code, 
  Terminal, 
  Globe, 
  Lock, 
  Unlock, 
  Heart,
  ExternalLink,
  Cpu,
  Coffee,
  Sparkles,
  Zap,
  Layout,
  Server,
  CheckCircle2,
  Moon,
  Sun,
  Languages,
  AlertCircle,
  CreditCard,
  Palette,
  Box,
  Command,
  Code2,
  FileCode2,
  Braces,
  Phone
} from 'lucide-react';

const Portfolio = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [activeSection, setActiveSection] = useState('about');
  const [scrolled, setScrolled] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [lang, setLang] = useState('en'); // Default 'id'

  // SEO & Title Handling
  useEffect(() => {
    document.title = lang === 'id' ? "Mancini Putra | MP" : "Mancini Putra | MP";
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = "description";
      document.head.appendChild(meta);
    }
    meta.content = lang === 'id' 
      ? "Portofolio Mancini Putra. Full stack developer, spesialis Python, HTML, dan solusi web kreatif."
      : "Portfolio of Mancini Putra. Full stack developer, femboy aesthetic enthusiast, specializing in Python, HTML, and creative web solutions.";
  }, [lang]);

  // Handle scroll for navbar and active section
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
      
      const sections = ['about', 'skills', 'repos', 'contact'];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= 300) {
            setActiveSection(section);
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Translations & Localized Data
  const t = {
    en: {
      nav: { about: 'About', skills: 'Skills', repos: 'Repos', contact: 'Contact', hire: 'Hire Me' },
      hero: {
        status: 'Open for Commissions',
        subtitle: 'Aesthetic engineering for the digital world.',
        role: 'Full Stack Developer • UI/UX Enthusiast'
      },
      langs: { title: 'Languages Spoken' },
      skills: { title: 'Tech', titleAccent: 'Arsenal', subtitle: 'Tools and technologies I use to bring ideas to life.', proficient: 'Proficient', learning: 'Learning!' },
      repos: { title: 'Project', titleAccent: 'Status', subtitle: 'Real-time status of my GitHub repositories', active: 'Active', inactive: 'Inactive', all: 'All' },
      contact: {
        accent: 'Commission Info',
        title: 'Work With Me',
        card1: {
          title: 'Custom App / Website',
          desc: 'Perfect for personal portfolios, simple tools, or custom private Discord bots.',
          cta: 'Order Now',
          price: 'USD$ 50',
          unit: '/project',
          features: ['Fixed Price (Excl. Fees)', 'Basic SEO Included', 'Discord Bot Included'],
          // Updated to array for multiple notes
          notes: [
            { 
              text: "Exchange rate follows XE.com.", 
              link: "https://www.xe.com/currencyconverter/convert/?Amount=1&From=USD&To=IDR",
              linkLabel: "Check Rate",
              type: "info"
            },
            { 
              text: "Customer covers PayPal fees. Upfront 30% required.", 
              type: "warning"
            }
          ]
        },
        card2: {
          title: 'Remote Hire',
          desc: 'Need a helping hand? Hire me hourly for maintenance, scripting, or updates.',
          cta: 'Contact Me',
          price: 'USD$ 5',
          unit: '/hour',
          features: ['Flexible Hours', 'Live Updates', 'Priority Support'],
          notes: [
            { text: "Hourly rate via PayPal.", type: "credit" }
          ]
        },
        footer: 'All rights reserved. Design inspired by soft aesthetics.',
        madeWith: 'Made with'
      }
    },
    id: {
      nav: { about: 'Tentang', skills: 'Keahlian', repos: 'Repo', contact: 'Kontak', hire: 'Hubungi' },
      hero: {
        status: 'Buka Komisi',
        subtitle: 'Rekayasa estetika untuk dunia digital.',
        role: 'Full Stack Developer • Penggemar UI/UX'
      },
      langs: { title: 'Bahasa yang Dikuasai' },
      skills: { title: 'Gudang', titleAccent: 'Teknologi', subtitle: 'Alat dan teknologi yang saya gunakan untuk menghidupkan ide.', proficient: 'Mahir', learning: 'Belajar!' },
      repos: { title: 'Status', titleAccent: 'Proyek', subtitle: 'Status real-time repositori GitHub saya', active: 'Aktif', inactive: 'Nonaktif', all: 'Semua' },
      contact: {
        accent: 'Info Komisi',
        title: 'Kerja Sama',
        card1: {
          title: 'Aplikasi / Website Kustom',
          desc: 'Cocok untuk portofolio pribadi, alat sederhana, atau bot Discord pribadi kustom.',
          cta: 'Pesan Sekarang',
          price: 'Rp 1.000.000',
          unit: '/project',
          features: ['Harga Nego', 'Termasuk SEO Dasar', 'Termasuk Bot Discord'],
          notes: [
            { text: "Menerima QRIS, Transfer Bank, VA. Wajib DP 40% di awal.", type: "credit" }
          ]
        },
        card2: {
          title: 'Rekrut Remote',
          desc: 'Butuh bantuan? Sewa saya per jam untuk pemeliharaan, scripting, atau update.',
          cta: 'Hubungi Saya',
          price: 'Rp 50.000',
          unit: '/jam',
          features: ['Jam Fleksibel', 'Update Langsung', 'Prioritas Support'],
          notes: [
            { text: "Pembayaran mudah via QRIS/Bank.", type: "credit" }
          ]
        },
        footer: 'Hak cipta dilindungi. Desain terinspirasi oleh estetika lembut.',
        madeWith: 'Dibuat dengan'
      }
    }
  };

  const text = t[lang];

  // Contact Link Logic
  const getContactLink = () => {
    return lang === 'id' 
      ? "https://wa.me/6281398002543" 
      : "https://discord.gg/fQ4vFCh3kb";
  };

  const languagesList = [
    { name: lang === 'id' ? "Bahasa Inggris" : "English", native: "English", percent: 95, color: "bg-pink-400" },
    { name: lang === 'id' ? "Bahasa Melayu" : "Malay", native: "Malay", percent: 64, color: "bg-purple-400" },
    { name: lang === 'id' ? "Bahasa Jepang" : "Japanese", native: "Japanese", percent: 4, color: "bg-red-300" },
    { name: lang === 'id' ? "Bahasa Filipina" : "Tagalog", native: "Tagalog", percent: 2, color: "bg-yellow-300" },
  ];

  // Updated Skills List with Lucide Icons
  const skillsList = [
    { name: "Python", percent: 85, icon: Terminal, color: "text-blue-500 bg-blue-100" },
    { name: "HTML5", percent: 80, icon: FileCode2, color: "text-orange-500 bg-orange-100" },
    { name: "CSS", percent: 64, icon: Palette, color: "text-purple-500 bg-purple-100" },
    { name: "JavaScript", percent: 58, icon: Zap, color: "text-yellow-500 bg-yellow-100" },
    { name: "Bash/Shell", percent: 43, icon: Command, color: "text-gray-700 bg-gray-200" },
    { name: "Java", percent: 4, note: text.skills.learning, icon: Coffee, color: "text-red-500 bg-red-100" },
    { name: "Golang", percent: 1, note: text.skills.learning, icon: Box, color: "text-cyan-600 bg-cyan-100" },
  ];

  const reposList = [
    { name: "/manciniputra28", status: "Active", private: false, lang: "Config" },
    { name: "/JSTunnel", status: "Discontinued", private: true, lang: "JS" },
    { name: "/XyrenAdmin", status: "Active", private: true, lang: "Python" },
    { name: "/ProjectNyx", status: "Pending Work", private: true, lang: "TS" },
    { name: "/golonodesv1", status: "Discontinued", private: false, lang: "Go" },
    { name: "/sanatanhostingv1", status: "Discontinued", private: false, lang: "HTML" },
    { name: "/tcn", status: "Abandoned", private: true, lang: "Unknown" },
    { name: "/random", status: "Abandoned", private: true, lang: "Shell" },
    { name: "/glowing-invention", status: "Abandoned", private: true, lang: "JS" },
  ];

  const getStatusStyle = (status) => {
    switch (status) {
      case 'Active': return isDarkMode ? 'bg-green-900/30 text-green-400 border-green-800' : 'bg-green-100 text-green-700 border-green-200 shadow-green-100';
      case 'Pending Work': return isDarkMode ? 'bg-amber-900/30 text-amber-400 border-amber-800' : 'bg-amber-100 text-amber-700 border-amber-200 shadow-amber-100';
      case 'Discontinued': return isDarkMode ? 'bg-gray-800 text-gray-400 border-gray-700' : 'bg-gray-100 text-gray-500 border-gray-200';
      case 'Abandoned': return isDarkMode ? 'bg-red-900/20 text-red-400 border-red-900/50' : 'bg-red-50 text-red-400 border-red-100 opacity-70';
      default: return 'bg-gray-100 text-gray-500';
    }
  };

  const filteredRepos = activeTab === 'all' 
    ? reposList 
    : activeTab === 'active' 
      ? reposList.filter(r => r.status === 'Active' || r.status === 'Pending Work')
      : reposList.filter(r => r.status === 'Discontinued' || r.status === 'Abandoned');

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
    }
  };

  return (
    <main className={`min-h-screen font-sans selection:bg-pink-500 selection:text-white overflow-x-hidden relative transition-colors duration-700 ${isDarkMode ? 'bg-[#0f0f1a] text-pink-50' : 'bg-[#fff5f9] text-gray-700'}`}>
      
      {/* Global Background Noise */}
      <div className="fixed inset-0 w-full h-full overflow-hidden -z-20 pointer-events-none">
        <div className={`absolute inset-0 opacity-[0.03] ${isDarkMode ? 'brightness-50 invert' : ''}`} style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}></div>
      </div>

      {/* Interactive Navbar - Centered & Clean MP Logo */}
      <nav className={`fixed w-full z-50 transition-all duration-500 left-0 right-0 ${scrolled ? 'py-4' : 'py-6'}`}>
        <div className={`max-w-5xl mx-auto px-4 sm:px-6 transition-all duration-300 ${scrolled ? (isDarkMode ? 'bg-[#1a1a2e]/60 border-white/10' : 'bg-white/60 border-white/50') + ' backdrop-blur-xl shadow-lg rounded-full border' : ''}`}>
          
          <div className="relative flex justify-between items-center h-12 w-full">
            
            {/* 1. Left: Logo MP */}
            <div className="flex items-center cursor-pointer group z-10 w-24" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
              <span className={`font-extrabold text-2xl tracking-tighter transition-colors duration-300 ${isDarkMode ? 'text-pink-300' : 'text-pink-500'}`}>
                MP
              </span>
            </div>
            
            {/* 2. Center: Navigation Links (Absolutely Centered) */}
            <div className={`hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center rounded-full p-1 border backdrop-blur-sm transition-colors duration-300 ${isDarkMode ? 'bg-black/20 border-white/10' : 'bg-white/40 border-white/50'}`}>
              {['about', 'skills', 'repos', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`px-5 py-1.5 rounded-full text-sm font-medium transition-all duration-300 capitalize relative ${
                    activeSection === item 
                    ? 'text-pink-500 shadow-sm font-bold' 
                    : (isDarkMode ? 'text-gray-400 hover:text-pink-300' : 'text-gray-500 hover:text-pink-400')
                  }`}
                >
                  {activeSection === item && (
                    <span className={`absolute inset-0 rounded-full shadow-sm -z-10 animate-fade-in ${isDarkMode ? 'bg-[#2a2a40]' : 'bg-white'}`}></span>
                  )}
                  {text.nav[item]}
                </button>
              ))}
            </div>
            
            {/* 3. Right: Toggles & Hire Button */}
            <div className="flex items-center gap-3 z-10 w-auto justify-end">
              
              {/* Toggles Container */}
              <div className={`flex items-center gap-2 rounded-full p-1 border backdrop-blur-sm transition-colors duration-300 ${isDarkMode ? 'bg-black/20 border-white/10' : 'bg-white/40 border-white/50'}`}>
                {/* Theme Toggle */}
                <button 
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className={`p-2 rounded-full transition-all duration-300 hover:scale-110 ${isDarkMode ? 'bg-purple-900/50 text-yellow-300' : 'bg-yellow-100 text-orange-400 hover:bg-yellow-200'}`}
                  title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                >
                  {isDarkMode ? <Moon size={16} fill="currentColor" /> : <Sun size={16} fill="currentColor" />}
                </button>

                {/* Language Toggle */}
                <button 
                  onClick={() => setLang(lang === 'en' ? 'id' : 'en')}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold transition-all duration-300 ${isDarkMode ? 'bg-[#2a2a40] text-pink-300 hover:bg-[#3a3a50]' : 'bg-white text-pink-500 hover:bg-pink-50'}`}
                >
                  <Languages size={14} />
                  {lang.toUpperCase()}
                </button>
              </div>

              <a href="#contact" className="hidden md:block bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-6 py-2 rounded-full text-xs font-bold transition-all hover:shadow-lg hover:shadow-pink-500/25 transform hover:-translate-y-0.5 whitespace-nowrap">
                {text.nav.hire}
              </a>
            </div>

          </div>
        </div>
      </nav>

      {/* HERO SECTION: Dynamic Sky (Static/Clean for Light Mode) */}
      <section id="about" className="relative h-screen min-h-[700px] flex flex-col justify-center items-center overflow-hidden">
        
        {/* Dynamic Background Layer */}
        <div className="absolute inset-0 z-0 transition-all duration-[2000ms] ease-in-out">
          {/* Light Mode: Static Blue Sky Gradient (No Cycle)
             Dark Mode: Fixed Night Gradient
          */}
          <div className={`absolute inset-0 bg-[length:400%_400%] transition-opacity duration-1000 ${
            isDarkMode 
              ? 'bg-gradient-to-b from-slate-900 via-indigo-950 to-black opacity-100' 
              : 'bg-gradient-to-b from-sky-300 via-blue-100 to-white opacity-90'
          }`}></div>
          
          {/* Grid/Stars Overlay */}
          <div className="absolute inset-0 opacity-20" 
               style={{ 
                 backgroundImage: isDarkMode 
                   ? 'radial-gradient(#ffffff 1.5px, transparent 1.5px), radial-gradient(#ffffff 1px, transparent 1px)' 
                   : 'radial-gradient(#ffffff 2px, transparent 2px)', 
                 backgroundSize: isDarkMode ? '50px 50px, 20px 20px' : '30px 30px',
                 backgroundPosition: '0 0, 25px 25px'
               }}>
          </div>

          {/* Celestial Bodies - No Rotation in Light Mode */}
          <div className="absolute inset-0 pointer-events-none">
             {/* Sun - Visible only in Light Mode - Static Top Right or Center */}
             <div className={`absolute transition-all duration-1000 ${isDarkMode ? 'opacity-0 translate-y-20' : 'opacity-100 top-[10%] left-[50%] -translate-x-1/2'}`}>
                <div className="w-32 h-32 bg-yellow-300 rounded-full blur-[60px] opacity-80 mix-blend-screen absolute -top-4 -left-12"></div>
                <Sun size={80} className="text-yellow-100 animate-pulse relative" />
             </div>

             {/* Moon - Visible only in Dark Mode */}
             <div className={`absolute transition-all duration-1000 ${isDarkMode ? 'opacity-100 top-[15%] left-[50%] -translate-x-1/2' : 'opacity-0 -translate-y-20 top-[15%] left-[50%]'}`}>
                <div className="w-40 h-40 bg-indigo-500 rounded-full blur-[60px] opacity-40 mix-blend-screen absolute -top-8 -left-16"></div>
                <Moon size={100} className={`text-indigo-100 ${isDarkMode ? 'drop-shadow-[0_0_30px_rgba(255,255,255,0.3)]' : ''}`} />
             </div>
          </div>
          
          {/* Clouds/Fog Bottom Fade */}
          <div className={`absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t transition-colors duration-1000 ${isDarkMode ? 'from-[#0f0f1a] to-transparent' : 'from-white/40 to-transparent'}`}></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <div className={`backdrop-blur-md rounded-[3rem] p-10 md:p-14 border shadow-2xl animate-fade-in-up transition-colors duration-500 ${isDarkMode ? 'bg-black/40 border-white/10 shadow-purple-900/20' : 'bg-white/10 border-white/30 shadow-indigo-500/10'}`}>
            
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/20 backdrop-blur-md border border-white/10 text-white mb-6">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400"></span>
              </span>
              <span className="text-xs font-bold tracking-wide uppercase">{text.hero.status}</span>
            </div>

            <h1 className="text-5xl md:text-8xl font-extrabold text-white mb-6 tracking-tight drop-shadow-lg">
              Mancini
              <span className="block text-3xl md:text-5xl font-light mt-2 text-white/90">Putra</span>
            </h1>
            
            <p className="text-lg md:text-2xl text-white/90 max-w-2xl mx-auto mb-10 leading-relaxed font-light drop-shadow-md">
              {text.hero.subtitle}
              <br/>
              <span className="text-base md:text-lg opacity-70 mt-2 block font-normal">{text.hero.role}</span>
            </p>

            <div className="flex justify-center gap-5">
              
              {/* GitHub */}
              <a href="https://github.com/manciniputra28" target="_blank" rel="noopener noreferrer" className="p-4 bg-white/10 backdrop-blur-md rounded-2xl hover:bg-white/20 hover:-translate-y-2 transition-all duration-300 text-white border border-white/20 group">
                <Github className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </a>

              {/* Instagram */}
              <a href="https://www.instagram.com/vireya.akane/" target="_blank" rel="noopener noreferrer" className="p-4 bg-white/10 backdrop-blur-md rounded-2xl hover:bg-white/20 hover:-translate-y-2 transition-all duration-300 text-white border border-white/20 group">
                <Instagram className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </a>

              {/* X */}
              <a href="https://x.com/narukeane" target="_blank" rel="noopener noreferrer" className="p-4 bg-white/10 backdrop-blur-md rounded-2xl hover:bg-white/20 hover:-translate-y-2 transition-all duration-300 text-white border border-white/20 group">
                <div className="w-6 h-6 flex items-center justify-center font-bold text-xl group-hover:scale-110 transition-transform">𝕏</div>
              </a>

              {/* Discord */}
              <a href="https://discord.gg/fQ4vFCh3kb" target="_blank" rel="noopener noreferrer" className="p-4 bg-white/10 backdrop-blur-md rounded-2xl hover:bg-white/20 hover:-translate-y-2 transition-all duration-300 text-white border border-white/20 group">
                <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </a>

              {/* WhatsApp (ID Only) */}
              {lang === 'id' && (
                <a href="https://wa.me/6281398002543" target="_blank" rel="noopener noreferrer" className="p-4 bg-white/10 backdrop-blur-md rounded-2xl hover:bg-white/20 hover:-translate-y-2 transition-all duration-300 text-white border border-white/20 group">
                  <Phone className="w-6 h-6 group-hover:scale-110 transition-transform" />
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Languages */}
      <section className="py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className={`backdrop-blur-md rounded-[2rem] p-8 md:p-10 shadow-xl border transition-colors duration-500 ${isDarkMode ? 'bg-[#1a1a2e]/50 border-white/5 shadow-purple-900/10' : 'bg-white/40 border-white/60'}`}>
            <div className="flex items-center gap-3 mb-8">
              <div className={`p-2 rounded-lg ${isDarkMode ? 'bg-purple-900/30 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                <Globe size={24} />
              </div>
              <h2 className={`text-2xl font-bold ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>{text.langs.title}</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {languagesList.map((l) => (
                <div key={l.name} className="group cursor-default">
                  <div className="flex justify-between mb-2 text-sm font-semibold tracking-wide">
                    <span className={`flex items-center gap-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {l.name} 
                      <span className={`text-xs font-normal px-2 py-0.5 rounded-full border ${isDarkMode ? 'bg-white/10 border-white/10 text-gray-400' : 'bg-white border-gray-100 text-gray-400'}`}>
                        {l.native}
                      </span>
                    </span>
                    <span className={isDarkMode ? 'text-pink-400' : 'text-gray-600'}>{l.percent}%</span>
                  </div>
                  <div className={`h-4 rounded-full overflow-hidden shadow-inner border ${isDarkMode ? 'bg-black/30 border-white/5' : 'bg-white border-white/50'}`}>
                    <div 
                      className={`h-full ${l.color} rounded-full transition-all duration-1000 ease-out group-hover:scale-x-105 origin-left relative overflow-hidden`}
                      style={{ width: `${l.percent}%` }}
                    >
                      <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Redesigned Skills Section with Lucide Icons */}
      <section id="skills" className="py-20 px-6 relative">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>{text.skills.title} <span className="text-pink-500">{text.skills.titleAccent}</span></h2>
            <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>{text.skills.subtitle}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {skillsList.map((skill) => {
              const IconComponent = skill.icon;
              return (
                <div key={skill.name} className={`group relative rounded-2xl p-5 border hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col items-center text-center gap-3 ${isDarkMode ? 'bg-[#1e1e2f]/60 border-white/5 hover:border-pink-500/30' : 'bg-white/80 border-white/60 hover:border-pink-200'}`}>
                  
                  {/* Icon Container */}
                  <div className={`p-4 rounded-2xl mb-1 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3 ${isDarkMode ? 'bg-[#2a2a40]' : 'bg-white shadow-sm'} ${skill.color}`}>
                    <IconComponent size={28} />
                  </div>
                  
                  <div className="w-full">
                    <h3 className={`font-bold text-base mb-1 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{skill.name}</h3>
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-full bg-gray-200/50 rounded-full h-1.5 overflow-hidden">
                        <div className={`h-full rounded-full ${isDarkMode ? 'bg-pink-500' : 'bg-pink-400'}`} style={{ width: `${skill.percent}%` }}></div>
                      </div>
                      <span className={`text-xs font-medium ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                        {skill.note ? skill.note : `${skill.percent}%`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Repo Status */}
      <section id="repos" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
            <div>
              <h2 className={`text-3xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                {text.repos.title} <span className="text-purple-500">{text.repos.titleAccent}</span>
              </h2>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{text.repos.subtitle}</p>
            </div>
            
            <div className={`backdrop-blur p-1.5 rounded-xl shadow-sm border inline-flex ${isDarkMode ? 'bg-[#1e1e2f]/50 border-white/10' : 'bg-white/50 border-white'}`}>
              {['all', 'active', 'inactive'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                    activeTab === tab 
                    ? (isDarkMode ? 'bg-[#2a2a40] text-pink-300 shadow-sm' : 'bg-white text-gray-800 shadow-sm')
                    : (isDarkMode ? 'text-gray-500 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600')
                  }`}
                >
                  {text.repos[tab]}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRepos.map((repo, idx) => (
              <div key={idx} className={`rounded-xl p-5 border hover:shadow-lg transition-all group flex flex-col justify-between h-full ${isDarkMode ? 'bg-[#1e1e2f]/60 border-white/5 hover:border-pink-500/30 hover:shadow-pink-900/10' : 'bg-white border-gray-100 hover:border-pink-200 hover:shadow-pink-100'}`}>
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2 rounded-lg transition-colors ${isDarkMode ? 'bg-white/5 text-gray-500 group-hover:text-pink-400 group-hover:bg-pink-900/20' : 'bg-gray-50 text-gray-400 group-hover:text-pink-500 group-hover:bg-pink-50'}`}>
                      {repo.private ? <Lock size={16} /> : <Unlock size={16} />}
                    </div>
                    <span className={`text-[10px] font-mono px-2 py-1 rounded border ${isDarkMode ? 'bg-white/5 border-white/5 text-gray-400' : 'bg-gray-50 text-gray-400 border-gray-100'}`}>
                      {repo.lang}
                    </span>
                  </div>
                  <h3 className={`font-bold font-mono text-sm mb-4 truncate transition-colors ${isDarkMode ? 'text-gray-200 group-hover:text-pink-400' : 'text-gray-700 group-hover:text-pink-500'}`}>
                    {repo.name}
                  </h3>
                </div>
                
                <div className={`flex items-center gap-2 text-xs font-semibold px-3 py-2 rounded-lg border w-fit ${getStatusStyle(repo.status)}`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${repo.status === 'Active' ? 'bg-green-500 animate-pulse' : 'bg-current opacity-50'}`}></div>
                  {text.repos[repo.status.toLowerCase().replace(' ', '')] || repo.status}
                </div>
              </div>
            ))}
          </div>
          
          {filteredRepos.length === 0 && (
            <div className={`rounded-2xl p-12 text-center border border-dashed ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white/50 border-gray-300'}`}>
              <p className="text-gray-400 italic">No repositories found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* For Hire / Pricing */}
      <section id="contact" className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-pink-500 font-bold tracking-widest text-xs uppercase mb-2 block">{text.contact.accent}</span>
            <h2 className={`text-4xl font-extrabold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>{text.contact.title}</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Card 1: Project */}
            <div className={`rounded-3xl p-8 border hover:-translate-y-2 transition-transform duration-300 relative overflow-hidden group ${isDarkMode ? 'bg-[#1e1e2f] border-purple-900/30 shadow-purple-900/10' : 'bg-white border-purple-100 shadow-xl shadow-purple-100/50'}`}>
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Layout size={120} className={isDarkMode ? 'text-purple-400' : 'text-gray-800'} />
              </div>
              <div className="relative z-10">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${isDarkMode ? 'bg-purple-900/30 text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
                  <Zap size={24} />
                </div>
                <h3 className={`text-xl font-bold mb-2 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>{text.contact.card1.title}</h3>
                <p className={`text-sm mb-6 h-10 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{text.contact.card1.desc}</p>
                
                <div className="flex items-end gap-1 mb-8">
                  <span className={`text-3xl font-extrabold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>{text.contact.card1.price}</span>
                  <span className="text-gray-400 text-sm mb-1">{text.contact.card1.unit}</span>
                </div>

                <div className="flex flex-col gap-2 mb-6">
                  {text.contact.card1.notes.map((note, idx) => (
                    <div key={idx} className={`p-3 rounded-lg text-xs flex gap-2 border ${
                      note.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-600' :
                      note.type === 'info' ? 'bg-blue-500/10 border-blue-500/30 text-blue-600' :
                      'bg-purple-500/10 border-purple-500/30 text-purple-600'
                    }`}>
                       {note.type === 'warning' && <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />}
                       {note.type === 'info' && <Globe size={14} className="flex-shrink-0 mt-0.5" />}
                       {note.type === 'credit' && <CreditCard size={14} className="flex-shrink-0 mt-0.5" />}
                       
                       <span>
                         {note.text} {note.link && <a href={note.link} target="_blank" rel="noreferrer" className="underline font-bold">{note.linkLabel}</a>}
                       </span>
                    </div>
                  ))}
                </div>

                <ul className="space-y-3 mb-8 text-sm text-gray-500">
                  {text.contact.card1.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-2"><CheckCircle2 size={16} className="text-purple-500" /> {feat}</li>
                  ))}
                </ul>

                <a href={getContactLink()} target="_blank" rel="noreferrer" className="block w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-center transition-colors shadow-lg shadow-purple-600/30">
                  {text.contact.card1.cta}
                </a>
              </div>
            </div>

            {/* Card 2: Hourly */}
            <div className={`rounded-3xl p-8 border hover:-translate-y-2 transition-transform duration-300 relative overflow-hidden group ${isDarkMode ? 'bg-[#1e1e2f] border-pink-900/30 shadow-pink-900/10' : 'bg-white border-pink-100 shadow-xl shadow-pink-100/50'}`}>
               <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Cpu size={120} className={isDarkMode ? 'text-pink-400' : 'text-gray-800'} />
              </div>
              <div className="relative z-10">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${isDarkMode ? 'bg-pink-900/30 text-pink-300' : 'bg-pink-100 text-pink-600'}`}>
                  <Coffee size={24} />
                </div>
                <h3 className={`text-xl font-bold mb-2 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>{text.contact.card2.title}</h3>
                <p className={`text-sm mb-6 h-10 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{text.contact.card2.desc}</p>
                
                <div className="flex items-end gap-1 mb-8">
                  <span className={`text-3xl font-extrabold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>{text.contact.card2.price}</span>
                  <span className="text-gray-400 text-sm mb-1">{text.contact.card2.unit}</span>
                </div>

                <div className="flex flex-col gap-2 mb-6">
                  {text.contact.card2.notes.map((note, idx) => (
                    <div key={idx} className={`p-3 rounded-lg text-xs flex gap-2 border ${
                       'bg-pink-500/10 border-pink-500/30 text-pink-600'
                    }`}>
                       <CreditCard size={14} className="flex-shrink-0 mt-0.5" />
                       <span>{note.text}</span>
                    </div>
                  ))}
                </div>

                <ul className="space-y-3 mb-8 text-sm text-gray-500">
                  {text.contact.card2.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-2"><CheckCircle2 size={16} className="text-pink-500" /> {feat}</li>
                  ))}
                </ul>

                <a href={getContactLink()} target="_blank" rel="noreferrer" className={`block w-full py-3 rounded-xl border-2 font-bold text-center transition-colors ${isDarkMode ? 'bg-transparent border-pink-500 text-pink-400 hover:bg-pink-900/20' : 'bg-white border-pink-500 text-pink-600 hover:bg-pink-50'}`}>
                  {text.contact.card2.cta}
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={`backdrop-blur-md py-10 border-t ${isDarkMode ? 'bg-[#0f0f1a]/80 border-white/5' : 'bg-white/80 border-white'}`}>
        <div className="max-w-4xl mx-auto px-6 flex flex-col items-center gap-4 text-center">
          <div className={`flex items-center gap-2 font-bold ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
             <Sparkles size={16} className="text-pink-500" /> Mancini Putra
          </div>
          <div className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} {text.contact.footer}
          </div>
          <div className={`flex items-center gap-2 text-xs px-3 py-1 rounded-full ${isDarkMode ? 'bg-white/5 text-gray-400' : 'bg-gray-50 text-gray-400'}`}>
            {text.contact.madeWith} <Heart size={10} className="text-red-400 fill-red-400 animate-pulse" /> using React & Tailwind
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes dayNightCycle {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes spinSlow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-day-night-cycle {
          animation: dayNightCycle 20s ease-in-out infinite;
        }
        .animate-spin-slow {
          animation: spinSlow 30s linear infinite;
        }
        .animate-fade-in { animation: fadeIn 0.3s ease-out forwards; }
        .animate-fade-in-up { animation: fadeInUp 0.8s ease-out forwards; }
        
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </main>
  );
};

export default Portfolio;