(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_page_jsx_23f3c43e._.js",
  "static/chunks/node_modules_f83a2356._.js"
],
    source: "dynamic"
});
